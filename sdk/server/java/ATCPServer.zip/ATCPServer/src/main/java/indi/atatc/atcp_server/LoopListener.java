package indi.atatc.atcp_server;

import indi.atatc.atcp_server.packages.basics.Basics;
import indi.atatc.atcp_server.packages.data.ID;

public abstract class LoopListener extends Basics.StructureClass.Listener {}
