package indi.atatc.atcp_server;

import indi.atatc.atcp_server.packages.data.ID;
import indi.atatc.atcp_server.packages.log.Log;

import java.io.IOException;
import java.net.Socket;
import java.util.HashMap;

public final class Connection {
    private final Socket cSocket;
    private final ID.IP ip;

    Socket getSocket() {
        return cSocket;
    }

    Connection(Socket cSocket) {
        this.cSocket = cSocket;
        ip = new ID.IP(cSocket.getInetAddress().getHostName());
    }

    public ID.IP getIP() {
        return ip;
    }

    void abort() throws IOException {
        if (!cSocket.isClosed()) {
            cSocket.close();
        }
    }

    @Override
    public String toString() {
        return getIP().toString();
    }
}
