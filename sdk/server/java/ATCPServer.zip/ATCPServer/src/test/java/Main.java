import indi.atatc.atcp_server.*;
import indi.atatc.atcp_server.Process;
import indi.atatc.atcp_server.packages.basics.Basics;
import indi.atatc.atcp_server.packages.data.ID;
import indi.atatc.atcp_server.packages.log.Log;

public class Main {
    public static void main(String[] args) {
        Server.Configuration configuration = new Server.Configuration();
        configuration.name = "ATCP Official Test";
        configuration.port = 2000;
        configuration.project = "ATCP";
        configuration.type = "official";
        Basics.ContainerClass.Flag flag = new Basics.ContainerClass.Flag("flag text");
        Server server = new Server(configuration) {
            private int times = 0;

            @Override
            public Process onConnected(Connection connection) {
                times ++;
                if (times == 20) {
                    stop();
                }
                return new Process(this, connection) {
                    @Override
                    protected void onSent(ID.MID mid) {

                    }

                    @Override
                    protected void onRecved(ID.MID mid, String result, Flags flags) {
                    }

                    @Override
                    protected String process(String msg, Flags flags) {
                        Log.getInstance().publish(msg, Log.DebugLevel.INFO);

                        String[] msgInParas = Basics.TextClass.split(msg, "@");
                        switch (msgInParas[0]) {
                            case "test":
                                return "test recved: " + msgInParas[1];
                        }
                        return "recved msg: " + msg;

                    }
                };
            }
        };
        LoopListener loopListener = new LoopListener() {
            @Override
            public boolean when() {
                return false;
            }

            @Override
            public void run() {

            }
        };
        server.addLoopListener(new LoopListener() {
            @Override
            public boolean when() {
                return false;
            }

            @Override
            public void run() {

            }
        });
        server.start(Server.Mode.T);
    }
}
