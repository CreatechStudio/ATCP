Project Started On: 2020.5.14

Remote Info:

| Name                        | Usage |
| --------------------------- | ----- |
| name                        |       |
| project                     |       |
| type                        |       |
| process_id (to client only) |       |
| message_blocking            |       |

